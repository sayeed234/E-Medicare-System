<base href="http://localhost/project/citizen/mrequest">

<?php
	
	include("../library/connectdb.php");
	include ("citizen.php");
	$run = new connection();
	echo "Request accepted";

?>