<!DOCTYPE html>
<html>
<head>
	<title> Notice board</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
    <style type="text/css">
        
 
.h2{

   /* background-color: #00ff00;*/
    /* text-shadow: 2px 2px #0000ff;*/
}


  

.demo{
  background-color: #1d417a;
  text-align: center;
  color: white;


}




    </style>
</head>
<body id="u_home">


 <div class='panel panel-default'>

        <div class='panel-heading text-center table-top'>
          <h4 class="h2"> Medical service list</h4>
        </div>
    
  </div>

          <div class='panel panel-default'>

             <div class='panel-body'>

                    
                    
       <div class="demo">
         <h2 class="">Medical Services   </h2>
         <h4 class="">Services, Departments, Divisions and Programs at UCLA Health </h4>

        </div>


                    <!-- 1st notice panel -->

                    <div class='col-md-6'> 


                         <!--    Top view -->

                      

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                 
                                   <div class="a"> clinical service </div>
                               </div>   

                                 <div class="col-md-6">
                                  

                                      Cancer Services <br>
                                      Heart/Cardiovascular Services <br>
                                      LGBTQ Health <br>
                                      Men’s Health <br>
                                      Pediatrics <br>

                                     

                                 </div>
                                 <div class="col-md-6">

                                 

                                  Transplantation Services
                                  Women’s Health
                                  Weight Management
                                  All Divisions & Programs


                                 </div>


                           </div>

                          </div>

                          <!-- 1st end -->
                          <!-- 2nd start -->
                            <div class='col-md-6'> 


                         <!--    Top view -->

                      

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                 
                                   <div class="a"> clinical service </div>
                               </div>   

                                 <div class="col-md-6">
                                  

                                      Cancer Services <br>
                                      Heart/Cardiovascular Services <br>
                                      LGBTQ Health <br>
                                      Men’s Health <br>
                                      Pediatrics <br>

                                      

                                 </div>
                                 <div class="col-md-6">

                                 

                                  Transplantation Services
                                  Women’s Health
                                  Weight Management
                                  All Divisions & Programs

                                 </div>


                           </div>

                          </div>

                         <!-- 2nd end -->
                         <!-- 3rd start -->
                           <div class='col-md-6'> 


                         <!--    Top view -->

                      

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                 
                                   <div class="a"> clinical service </div>
                               </div>   

                                 <div class="col-md-6">
                                  

                                      Cancer Services <br>
                                      Heart/Cardiovascular Services <br>
                                      LGBTQ Health <br>
                                      Men’s Health <br>
                                      Pediatrics <br>

                                 </div>
                                 <div class="col-md-6">

                                 

                                  Transplantation Services
                                  Women’s Health
                                  Weight Management
                                  All Divisions & Programs

                                 </div>


                           </div>

                          </div>


                          <!-- 3rd end -->



                          <!-- 4th start -->

                           <div class='col-md-6'> 


                         <!--    Top view -->

                      

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                 
                                   <div class="a"> clinical service </div>
                               </div>   

                                 <div class="col-md-6">
                                  

                                      Cancer Services <br>
                                      Heart/Cardiovascular Services <br>
                                      LGBTQ Health <br>
                                      Men’s Health <br>
                                      Pediatrics <br>

                                 </div>
                                 <div class="col-md-6">

                                 

                                  Transplantation Services
                                  Women’s Health
                                  Weight Management
                                  All Divisions & Programs

                                 </div>


                           </div>

                          </div>


                 


                          <!-- 4th end  -->

                          <!-- 5 start -->

                         
                           <div class='col-md-6'> 


                         <!--    Top view -->

                      

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                 
                                   <div class="a"> clinical service </div>
                               </div>   

                                 <div class="col-md-6">
                                  

                                      Cancer Services <br>
                                      Heart/Cardiovascular Services <br>
                                      LGBTQ Health <br>
                                      Men’s Health <br>
                                      Pediatrics <br>

                                 </div>
                                 <div class="col-md-6">

                                 

                                  Transplantation Services
                                  Women’s Health
                                  Weight Management
                                  All Divisions & Programs

                                 </div>


                           </div>

                          </div>


                        

                          <!-- 5 end -->

    



<!--  -->

  </div>
</div>




	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/script.js"></script>


</body>
</html>