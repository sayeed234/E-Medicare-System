<!DOCTYPE html>
<html>
<head>
	<title> Notice board</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
    <style type="text/css">
        
 
.h2{

    /*background-color: #00ff00;
     text-shadow: 2px 2px #0000ff;*/
}


     div.a {
    text-align:left;
    float:left;
}

div.b {

    text-align:right;
}
.card{
  background-color: #e6f2ff;
}




    </style>
</head>
<body id="u_home">


 <div class='panel panel-default'>

        <div class='panel-heading text-center table-top'>
          <h4 class="h2"> Medi Center Notice </h4>
        </div>
    
  </div>

          <div class='panel panel-default'>

             <div class='panel-body'>

                    
                    
                    <!--  Left div -->


                    <!-- 1st notice panel -->

                    <div class='col-md-4'> 


                         <!--    Top view -->

                            

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                   <!-- <div>Notice 1    date:14/09/18</div> -->
                                   <div class="a"> Notice 1 </div>
                                    <div class="b"> Date:14/09/18</div>

                                   

                               </div>

                          </div>

                            <!-- Top view end -->


                           <div class='col-md-8'>

                                
                            <div class="card">
      <div class="card-body text-left">
        <p class="card-text">A noticeboard is a board which is usually attached to a wall in order to display notices giving information about something. [British] She added her name to the list on the noticeboard. regional note: in AM, use bulletin board. Synonyms: pinboard, bulletin board More Synonyms of noticeboard.
        </p>
      </div>
    </div>

                            </div>

                           <div class='col-md-4'>


                                    <div>
                                           <img src='../img/medicenter/notice/notice1.jpg'/ width='100%' height='120px'>
                                           <div>
                                           <a href="http://google.com" class="btn btn-success">see more</a>
                                         </div>
                                   </div>

                                  
                               <!-- </br></br>
                                </br></br>
                                </br></br>
                                <hr/>
                               <div class='text-justify'> </div>
 -->
                            </div>

                            
                    </div>


                      <!-- 1st notice panel end -->

                        <!-- 2nd notice panel start -->

                     <div class='col-md-4'> 


                         <!--    Top view -->

                            

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>
                                    <div class="a"> Notice 2 </div>
                                    <div class="b"> Date:14/09/18</div>


                               </div>

                          </div>

                            <!-- Top view end -->


                           <div class='col-md-8'>

                                
                                                  <div class="card">
      <div class="card-body text-left">
        <p class="card-text">A noticeboard is a board which is usually attached to a wall in order to display notices giving information about something. [British] She added her name to the list on the noticeboard. regional note: in AM, use bulletin board. Synonyms: pinboard, bulletin board More Synonyms of noticeboard.</p>
      </div>
    </div>

                            </div>

                           <div class='col-md-4'>

                            
                                    <div>
                                            <img src='../img/medicenter/notice/notice2.jpg'/ width='100%' height='120px'>
                                            <div>
                                           <a href="http://google.com" class="btn btn-success">see more</a>
                                         </div>
                                   </div>

                                  
                               <!-- </br></br>
                                </br></br>
                                </br></br>
                                <hr/>
                               <div class='text-justify'> </div>
 -->
                            </div>

                            
                    </div>

                  
                        <!-- 2nd notice panel end -->

                        <!-- 3rd notice panel start -->

                     <div class='col-md-4'> 


                         <!--    Top view -->

                            

                            <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                                  <div class="a"> Notice 3 </div>
                                    <div class="b"> Date:14/09/18</div>


                               </div>

                          </div>

                            <!-- Top view end -->


                           <div class='col-md-8'>

                                
                                                <div class="card">
      <div class="card-body text-left">
        <p class="card-text">A noticeboard is a board which is usually attached to a wall in order to display notices giving information about something. [British] She added her name to the list on the noticeboard. regional note: in AM, use bulletin board. Synonyms: pinboard, bulletin board More Synonyms of noticeboard.</p>
      </div>
    </div>

                            </div>

                           <div class='col-md-4'>

                            
                                    <div>
                                           <img src='../img/medicenter/notice/notice3.jpg'/ width='100%' height='120px'>
                                           <div>
                                           <a href="http://google.com" class="btn btn-success">see more</a>
                                         </div>
                                   </div>

                                  
                               <!-- </br></br>
                                </br></br>
                                </br></br>
                                <hr/>
                               <div class='text-justify'> </div>
 -->
                            </div>

                            
                    </div>



                   <!-- 3rd notice panel end -->


                    <!-- 4rt notice pnael start -->


<!-- <!-- 
                    <div class='col-md-4'> 


                         <!--    Top view -->

                            

                           

             <!-- 4th notice panel -->



                    <!-- 4th p0art end -->

                    <!--  Right div -->

                  <!-- <div class='col-md-3'> 
                            <div class='panel panel-default img-padding'>

                                <div class='panel-body img-padding'>
                                    
                                    
        
                                    <div>
                                           <img src='../img/doctor/doc.jpg'/ width='100%' height='120px'>
                                   </div>





                             </div>
                            
                       </div>

                          <div class='text-center'><button class='btn btn-primary'>Contact</button></div>

               </div> -->





               </div>
            
            </div>

        
 <!-- new panel start  -->
 
          <div class='panel panel-default'>

             <div class='panel-body'>

                    
                    
                    <!--  Left div -->


                    <!-- 1st notice panel -->

                        <div class='col-md-4'> 

                    <div class='panel panel-default borderless_panel'>
                                
                                <div class='panel-heading text-center overview'>

                               <div class="a"> Notice 4 </div>
                                    <div class="b"> Date:14/09/18</div>


                               </div>

                          </div>

                            <!-- Top view end -->


                           <div class='col-md-8'>

                                                 <div class="card">
      <div class="card-body text-left text-justify">
        <p class="card-text">A noticeboard is a board which is usually attached to a wall in order to display notices giving information about something. [British] She added her name to the list on the noticeboard. regional note: in AM, use bulletin board. Synonyms: pinboard, bulletin board More Synonyms of noticeboard.</p>
      </div>
    </div>
                            </div>

                           <div class='col-md-4'>

                            
                                    <div>
                                            <img src='../img/medicenter/notice/notice4.png'/ width='100%' height='120px'>
                                            <div>
                                           <a href="http://google.com" class="btn btn-success">see more</a>
                                         </div>
                                   </div>
                                     
                                 
                            </div>

                            
                    </div>
 




</div>
</div>
































	<!-- 
		   <div class="container">
               <div class="row justify-content-center">

                <div class="row">



                     <div class="col-md-12 col-sm-10 " style="background-color:green;">

                            <h1 class="text-center " style="background-color:#00ffff;" > Welcome to Medi-notice  </h1>
                         
                      </div>

                   </div>  


               </div>
           </div>
 -->


		

	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/script.js"></script>


</body>
</html>